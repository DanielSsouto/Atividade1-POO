
public interface Divida {
    void pagarDivida(float decrementa);
    float mostrarDivida();
}
