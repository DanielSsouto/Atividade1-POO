
public class SuperHeroi extends Personagem {
    SuperHeroi(String Nome, String NomeReal){
        super(Nome, NomeReal);
    }
}
