
public class PilhaCheia extends PilhaExcecao {
    
    public PilhaCheia() {
        
    }
    
    public PilhaCheia(String msg) {
        super(msg);
    }
    
}
