
public class PilhaExcecao extends RuntimeException {
    
    public PilhaExcecao() {
        
    }
    
    public PilhaExcecao(String msg) {
        super(msg);
    }
}
