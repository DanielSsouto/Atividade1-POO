
public class PilhaVazia extends PilhaExcecao {
    
    public PilhaVazia() {
        
    }
    
    public PilhaVazia(String msg) {
        super(msg);
    }
}
